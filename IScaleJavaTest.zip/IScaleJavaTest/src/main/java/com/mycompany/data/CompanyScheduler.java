/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.data;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Bryan
 */
public class CompanyScheduler {
 
    protected List<ProjectPlan> projectPlans = new ArrayList<ProjectPlan>();
    protected String companyName;

    public CompanyScheduler(){
    }
    
    public List<ProjectPlan> getProjectPlans() {
        return projectPlans;
    }

    public void setProjectPlans(List<ProjectPlan> projectPlans) {
        this.projectPlans = projectPlans;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
    
}
