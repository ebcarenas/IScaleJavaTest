/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.data;

import java.util.Comparator;

/**
 *
 * @author Bryan
 */
public class SortbyStartDate implements Comparator<Task> {

    @Override
    public int compare(Task t, Task t1) {
        return Integer.parseInt(t.startDate) - Integer.parseInt(t1.startDate);
    }
}
