/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.data;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Bryan
 */
public class ProjectPlan {
    
    protected List<Task> tasks = new ArrayList<Task>();
    protected String projectName;
    
    public ProjectPlan(){
    }

    public List<Task> getTasks() {
        return tasks;
    }

    public void setTasks(List<Task> tasks) {
        this.tasks = tasks;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }
    
}
