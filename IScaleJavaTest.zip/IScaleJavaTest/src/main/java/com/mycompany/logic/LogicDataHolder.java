/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.logic;

/**
 *
 * @author Bryan
 */
public class LogicDataHolder {
    
    private static LogicDataHolder dataHolder = null;
    private SchedulerLogic currentSchedulerLogic;
    private ProjectPlanLogic currentProjectPlanLogic;
    private TaskLogic currentTaskLogic;
    
    private LogicDataHolder(){
    }
    
    public static LogicDataHolder getInstance()
    {
        if (dataHolder == null)
            dataHolder = new LogicDataHolder();
 
        return dataHolder;
    }
    
    public SchedulerLogic getCurrentSchedulerLogic() {
        return currentSchedulerLogic;
    }

    public void setCurrentSchedulerLogic(SchedulerLogic currentSchedulerLogic) {
        this.currentSchedulerLogic = currentSchedulerLogic;
    }

    public ProjectPlanLogic getCurrentProjectPlanLogic() {
        return currentProjectPlanLogic;
    }

    public void setCurrentProjectPlanLogic(ProjectPlanLogic currentProjectPlanLogic) {
        this.currentProjectPlanLogic = currentProjectPlanLogic;
    }

    public TaskLogic getCurrentTaskLogic() {
        return currentTaskLogic;
    }

    public void setCurrentTaskLogic(TaskLogic currentTaskLogic) {
        this.currentTaskLogic = currentTaskLogic;
    }
}
