/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.logic;

import com.mycompany.data.CompanyScheduler;
import com.mycompany.data.ProjectPlan;
import java.io.IOException;

/**
 *
 * @author Bryan
 */
public class SchedulerLogic extends LogicBase implements ILogic {
    
    protected CompanyScheduler companyScheduler;
    protected ProjectPlan currentProjectPlan;
    protected ProjectPlanLogic currentProjectPlanLogic;
    
    public SchedulerLogic() throws IOException{
    }
    
    public void startCalenderApp(){
        try
        {
            //Load Data File Path property
            
            //If data path doesn't exists then create it
            if(!helper.isDirectoryExists(dataFilePath))
                helper.CreateDirectory(dataFilePath);
            
            System.out.println("Please key in your company name: ");
            String companyName = helper.readInputData();
            
            // Validate if company name is empty
            if (!helper.isEmptyString(companyName)){
                System.out.println("Loading company schedule for: " + companyName + "...");
                
                //Search for existing company data and load it to the company scheduler object else create a new object
                String companyDataFileName = dataFilePath + "\\" + helper.generateJsonFileName(companyName);
                if (helper.isFileExists(companyDataFileName)){
                    //Load data file to object
                    this.companyScheduler = dataObjMapper.mapFileToObject(helper.openAndReadFile(companyDataFileName), CompanyScheduler.class);
                }
                else
                {
                    //Create new object
                    this.companyScheduler = new CompanyScheduler();
                    this.companyScheduler.setCompanyName(companyName);
                    dataObjMapper.writeToFile(companyDataFileName, this.companyScheduler);
                }
                
                // Load Menu 
                this.load();
            }
            else
                System.out.println("Invalid company name.");
        }
        catch(Exception ex)
        {
            System.out.println("Error: " + ex.getMessage());
        }
    };
    
    
    @Override
    public void load() throws IOException {
          //If there is no existing project plan, ask user if he/she wants 
        // to create a new one else load the project plan list
       if (this.companyScheduler.getProjectPlans().size() > 0){
           show();
           System.out.println("Do you want to view a Project Plan? (Y/N): ");
           switch (helper.readInputData().toLowerCase()){
               case "y":
                   System.out.println("Please enter the Project Plan name you want to view: ");
                   String selectedProjectPlan = helper.readInputData();
                   if (isExistingItem(selectedProjectPlan))
                   {
                       this.currentProjectPlanLogic = new ProjectPlanLogic(this.companyScheduler);
                       setCurrentItem(selectedProjectPlan);
                       logicHolder.setCurrentSchedulerLogic(this);
                       this.currentProjectPlanLogic.load();
                   }
                   else
                   {
                       System.out.println("Invalid Input.");
                       helper.readInputData();
                       reloadList();
                   }
                   break;
               case "n":
                   System.out.println("Do you want to create a new project plan? (Y/N): ");
                   this.createProject();
                   break;
               default:
                   System.out.println("Invalid Input.");
                   helper.readInputData();
                   reloadList();
                   
            }
       }
       else
       {
           System.out.println("You don't have any project plans. Do you want to create one? (Y/N): ");
           this.createProject();
              
       }
    }

    @Override
    public void reloadList() throws IOException {
        load();
    }

    @Override
    public void show() {
        helper.drawUiHeader(this.companyScheduler.getCompanyName() + " Project Plans");
        int counter = 1;
        for(ProjectPlan pp : this.companyScheduler.getProjectPlans())
        {
          System.out.println(counter + "." + " " + pp.getProjectName());
          counter += 1;
        }
        System.out.println();
        helper.drawUiFooter();
    }

    @Override
    public void createItem(String name) throws IOException {
        ProjectPlan projectPlan = new ProjectPlan();
        projectPlan.setProjectName(name);
        this.companyScheduler.getProjectPlans().add(projectPlan);
        dataObjMapper.writeToFile(dataFilePath + "\\" + helper.generateJsonFileName(this.companyScheduler.getCompanyName()), this.companyScheduler);
    }

    @Override
    public void removeItem(int index) throws IOException {
        this.companyScheduler.getProjectPlans().remove(index);
        dataObjMapper.writeToFile(dataFilePath + "\\" + helper.generateJsonFileName(this.companyScheduler.getCompanyName()), this.companyScheduler);
    }

    @Override
    public void setCurrentItem(int index) {
        this.currentProjectPlanLogic.currentProjectPlan = this.companyScheduler.getProjectPlans().get(index);    
    }

    @Override
    public void setCurrentItem(String name) {
        for (ProjectPlan pp : this.companyScheduler.getProjectPlans())
        {
            if(pp.getProjectName().toLowerCase().equals(name.toLowerCase()))
            {
                this.currentProjectPlanLogic.currentProjectPlan =  pp;
                break;
            }
        }
    }

    @Override
    public boolean isExistingItem(String name) {
        boolean result = false;
        for(ProjectPlan pp : this.companyScheduler.getProjectPlans())
        {
            if (pp.getProjectName().toLowerCase().equals(name.toLowerCase()))
            {
                result = true;
                break;
            }
        }
        return result;
    }
    
    private void createProject() throws IOException{
        switch (helper.readInputData().toLowerCase()) {
               case "y":
                   System.out.println("Please enter the Project Name: ");
                   String projectName = helper.readInputData();
                   if (!helper.isEmptyString(projectName))
                       if (!isExistingItem(projectName))
                       {
                           createItem(projectName);
                           reloadList();
                       }
                       else
                       {
                           System.out.println("Invalid Input.");
                           helper.readInputData();
                           reloadList();
                       }
                   else
                   {
                       System.out.println("Invalid Input.");
                       helper.readInputData();
                       reloadList();
                   }      
                   break;
               case "n":
                   System.out.println("Press any key to exit...");
                   helper.readInputData();
                   break;
               default:
                   System.out.println("Invalid Input.");
                   helper.readInputData();
                   reloadList();
                   break;
           }
    }
    
}
