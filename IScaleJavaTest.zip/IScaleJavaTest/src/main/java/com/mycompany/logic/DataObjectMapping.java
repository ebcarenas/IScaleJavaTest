/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.logic;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;
import java.io.IOException;

/**
 *
 * @author Bryan
 */
public class DataObjectMapping {
    
    private static DataObjectMapping dataObjMapper = null;
    protected ObjectMapper objectMapper;
    
    private DataObjectMapping(){
    }
    
    public static DataObjectMapping getInstance()
    {
        if (dataObjMapper == null)
            dataObjMapper = new DataObjectMapping();
 
        return dataObjMapper;
    }
        
    public <T> void writeToFile(String fileName, Object dataObject) throws IOException{
        objectMapper = new ObjectMapper();
        objectMapper.writeValue(new File(fileName), dataObject);
    }
    
    public <T> T mapFileToObject(String data, Class<T> type) throws IOException{
        objectMapper = new ObjectMapper();
        T mappedObject = objectMapper.readValue(data, type);
        return mappedObject; 
    }
    
}
