/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.logic;

import java.io.IOException;

/**
 *
 * @author Bryan
 */
public interface ILogic {
    void load() throws IOException;
    void reloadList() throws IOException;
    void show();
    void createItem(String name) throws IOException;
    void removeItem(int index) throws IOException;
    void setCurrentItem(int index);
    void setCurrentItem(String name);
    boolean isExistingItem(String name);
}
