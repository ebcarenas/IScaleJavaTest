/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.logic;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.stream.Stream;

/**
 *
 * @author Bryan
 */
public class LogicHelper {
    
    private static LogicHelper helper = null;
    protected final String rootPath = Thread.currentThread().getContextClassLoader().getResource("").getPath();
    protected final String appConfigPath = rootPath + "com.mycompany.properties";
    
    private LogicHelper(){
    }
    
    public static LogicHelper getInstance()
    {
        if (helper == null)
            helper = new LogicHelper();
 
        return helper;
    }
    
    public boolean isEmptyString(String input){
        return input == null || input.isEmpty();
    }
    
    public boolean isFileExists(String filepath){
        File file = new File(filepath);
        return file.exists();
    }
    
    public boolean isDirectoryExists(String path){
        File dir = new File(path);
        return dir.exists();
    }
    
    public void CreateDirectory(String dirPath){
        File dir = new File(dirPath);
        dir.mkdir();    
    }
    
    public String openAndReadFile(String filePath) throws IOException {
	StringBuilder contentBuilder = new StringBuilder();
	try (Stream<String> stream = Files.lines( Paths.get(filePath), StandardCharsets.UTF_8)) 
	{
            stream.forEach(s -> contentBuilder.append(s).append("\n"));
	}
	catch (IOException e) 
	{
            throw e;
	}
	return contentBuilder.toString();
    }
    
    public String readInputData() throws IOException{
        String output = "";
        char c;
        while((c =(char)System.in.read()) != '\n')
        {
            output += c;
        }
        return output;
    }
    
    public String getAppPropertyValue(String propertyName) throws FileNotFoundException, IOException {
        Properties appProps = new Properties();
        appProps.load(new FileInputStream(appConfigPath));
        String propertyValue = appProps.getProperty(propertyName);
        return propertyValue;
    }
    
    public String generateJsonFileName(String input){
        String fileName = input.toLowerCase().replaceAll(" ", "_");
        return fileName + ".json";
    }

    public static <T> T convertInstanceOfObject(Object o, Class<T> clazz) {
        try {
            return clazz.cast(o);
        } 
        catch(ClassCastException e){
            return null;
        }
    }
    
    public static void drawUiHeader(String headerTitle){
        System.out.print("\033[H\033[2J"); 
        System.out.println("");
        System.out.println("------------------------------------------------------------------------");
        System.out.println(headerTitle);
        System.out.println("------------------------------------------------------------------------");
        System.out.println("");
    }
    
    public static void drawUiFooter(){
        System.out.println("------------------------------------------------------------------------");
        System.out.println("");
    }
    
    public boolean isValidDateInput(String inputDate){
        boolean result = true;
        SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
        try
        {
            Date newDate = format.parse(inputDate);
        }
        catch(ParseException ex)
        {
            result = false;
        }
        return result;
    }
    
    public String stringToDateFormat(String inputString) throws ParseException{
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
        Date date = format.parse(inputString);
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        return sdf.format(date);
    }
    
    public String dateToStringFormat(String inputString) throws ParseException{
        SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
        Date date = format.parse(inputString);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        return sdf.format(date);
    }
    
    public boolean isValidDateRange(String fromDate, String toDate) throws ParseException
    {
        if(Integer.parseInt(dateToStringFormat(fromDate)) > Integer.parseInt(dateToStringFormat(toDate)))
            return false;
        else
            return true;
    }
}
