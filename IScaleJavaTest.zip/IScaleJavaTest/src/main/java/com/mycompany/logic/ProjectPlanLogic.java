/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.logic;

import com.mycompany.data.CompanyScheduler;
import com.mycompany.data.ProjectPlan;
import com.mycompany.data.SortbyStartDate;
import com.mycompany.data.Task;
import java.io.IOException;
import java.text.ParseException;
import java.util.Collections;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Bryan
 */
public class ProjectPlanLogic extends LogicBase implements ILogic {
    
    protected CompanyScheduler companyScheduler;
    protected ProjectPlan currentProjectPlan;
    protected TaskLogic currentTaskLogic;
    
    public ProjectPlanLogic(CompanyScheduler companyScheduler) throws IOException{
        this.companyScheduler = companyScheduler;
    }

    @Override
    public void load() throws IOException{
        try 
        {
            if (this.currentProjectPlan.getTasks().size() > 0){
               show();
               System.out.println("Do you want to view a task? (Y/N): ");
               switch (helper.readInputData().toLowerCase()){
                   case "y":
                       System.out.println("Please enter the task name you want to view: ");
                       String selectedTask = helper.readInputData();
                       if (isExistingItem(selectedTask))
                       {
                           this.currentTaskLogic = new TaskLogic(this.companyScheduler, this.currentProjectPlan, this);
                           setCurrentItem(selectedTask);
                           logicHolder.setCurrentProjectPlanLogic(this);
                           currentTaskLogic.load();
                       }
                       else
                       {
                           System.out.println("Invalid Input.");
                           helper.readInputData();
                           this.reloadList();
                       }
                       break;
                   case "n":
                       System.out.println("Do you want to add new task? (Y/N): ");
                       this.createTask();
                       break;
                   default:
                       System.out.println("Invalid Input.");
                       helper.readInputData();
                       this.reloadList();
                }
            }
            else
            {
               System.out.println("You don't have any task on this project plan. Do you want to create one? (Y/N): ");
               this.createTask();
            }
        }
        catch(IOException ex)
        {
            System.out.println("Error: " + ex.getMessage());
        }
    
    }

    @Override
    public void reloadList() throws IOException{
        load();
    }

    @Override
    public void show() {
        helper.drawUiHeader(this.currentProjectPlan.getProjectName()+ " Project Tasks");
        int counter = 1;
        //Sort Tasks by Start Date
        Collections.sort(this.currentProjectPlan.getTasks(), new SortbyStartDate());
        for(Task task : this.currentProjectPlan.getTasks())
        {
            try {
                System.out.println(counter + "." + " " + task.getTaskName());
                System.out.println("Start Date: " + helper.stringToDateFormat(task.getStartDate()));
                System.out.println("End Date: " + helper.stringToDateFormat(task.getEndDate()));
                System.out.println("Status: " + task.getStatus());
                System.out.println();
            } catch (ParseException ex) {
                Logger.getLogger(ProjectPlanLogic.class.getName()).log(Level.SEVERE, null, ex);
            }
          counter += 1;
        }
        System.out.println();
        helper.drawUiFooter();
    }

    @Override
    public void createItem(String name) throws IOException{
        Task task = new Task();
        task.setTaskName(name);
        task.setStatus("Pending");
        //Set Start Date and End Date
        System.out.println("Please enter the Task Start Date (MM/dd/YYYY): ");
        String startDate = helper.readInputData();
        if (helper.isValidDateInput(startDate))
        {
            try {
               task.setStartDate(helper.dateToStringFormat(startDate));
            } catch (ParseException ex) {
              System.out.println("Invalid date input.");
              helper.readInputData();
              this.reloadList();
            }
        }
        else
        {
              System.out.println("Invalid date input.");
              helper.readInputData();
              this.reloadList();
        }
        System.out.println("Please enter the Task End Date (MM/dd/YYYY): ");
        String endDate = helper.readInputData();
        try {
            if (helper.isValidDateInput(endDate) && helper.isValidDateRange(startDate, endDate))
            {
                try {
                    task.setEndDate(helper.dateToStringFormat(endDate));
                } catch (ParseException ex) {
                    System.out.println("Invalid date input.");
                    helper.readInputData();
                    this.reloadList();
                }
            }
            else
            {
                System.out.println("Invalid date input.");
                helper.readInputData();
                this.reloadList();
            }
        } catch (ParseException ex) {
            Logger.getLogger(ProjectPlanLogic.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.currentProjectPlan.getTasks().add(task);
        //Update project plan from list with current project plan
        updateProjectPlan();
        dataObjMapper.writeToFile(dataFilePath + "\\" + helper.generateJsonFileName(this.companyScheduler.getCompanyName()), this.companyScheduler);
    }

    @Override
    public void setCurrentItem(int index) {
        this.currentTaskLogic.currentTask = this.currentProjectPlan.getTasks().get(index);
    }

    @Override
    public void setCurrentItem(String name){
        for (Task task : this.currentProjectPlan.getTasks())
        {
            if(task.getTaskName().toLowerCase().equals(name.toLowerCase()))
            {
                this.currentTaskLogic.currentTask =  task;
                break;
            }
        }
    }

    @Override
    public boolean isExistingItem(String name) {
        boolean result = false;
        for(Task task : this.currentProjectPlan.getTasks())
        {
            if (task.getTaskName().toLowerCase().equals(name.toLowerCase()))
            {
                result = true;
                break;
            }
        }
        return result;
    }

    @Override
    public void removeItem(int index) throws IOException {
        this.currentProjectPlan.getTasks().remove(index);
        //Update project plan from list with current project plan
        updateProjectPlan();
        dataObjMapper.writeToFile(dataFilePath + "\\" + helper.generateJsonFileName(this.companyScheduler.getCompanyName()), this.companyScheduler);
    }
    
    private void updateProjectPlan()
    {
        //Update project plan inside the sheduler
        for(ProjectPlan pp : this.companyScheduler.getProjectPlans())
        {
            if (pp.getProjectName().equals(this.currentProjectPlan.getProjectName()))
            {
                pp = this.currentProjectPlan;
                break;
            }
        }
    }
    
    private void createTask() throws IOException{
        switch (helper.readInputData().toLowerCase()) {
            case "y":
                System.out.println("Please enter the Task Name: ");
                String taskName = helper.readInputData();
                if (!helper.isEmptyString(taskName))
                    if (!isExistingItem(taskName))
                    {
                        createItem(taskName);
                        reloadList();
                    }
                    else
                    {
                        System.out.println("Task Exists!");
                        helper.readInputData();
                        reloadList();
                    }
                else
                {
                    System.out.println("Invalid Input.");
                    helper.readInputData();
                    reloadList();
                }      
                break;
            case "n":
                logicHolder.getCurrentSchedulerLogic().load();
                break;
            default:
                System.out.println("Invalid Input.");
                helper.readInputData();
                reloadList();
                break;
        }
    
    }
    
}
