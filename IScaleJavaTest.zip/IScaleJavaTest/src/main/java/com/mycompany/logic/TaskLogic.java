/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.logic;

import com.mycompany.data.CompanyScheduler;
import com.mycompany.data.ProjectPlan;
import com.mycompany.data.Task;
import java.io.IOException;
import java.text.ParseException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Bryan
 */
public class TaskLogic extends LogicBase implements ILogic {

    protected CompanyScheduler companyScheduler;
    protected ProjectPlan currentProjectPlan;
    protected Task currentTask;
    protected ProjectPlanLogic currentProjectPlanLogic;
    
    public TaskLogic(CompanyScheduler companyScheduler, ProjectPlan currentProjectPlan, ProjectPlanLogic currentProjectPlanLogic) throws IOException {
        this.companyScheduler = companyScheduler;
        this.currentProjectPlan = currentProjectPlan;
        this.currentProjectPlanLogic = currentProjectPlanLogic;
    }
    
    @Override
    public void load() throws IOException {
        try 
        {
            show();
            System.out.println("Do you want to update the task status?");
            switch (helper.readInputData().toLowerCase()){
                   case "y":
                       updateTaskStatus(); 
                       break;
                   case "n":
                       System.out.println("Do you want to add dependencies?");
                       if(helper.readInputData().toLowerCase().equals("y"))
                           addTaskDependency();
                       else
                           logicHolder.getCurrentProjectPlanLogic().load();
                       break;
                   default:
                       System.out.println("Invalid Input.");
                       helper.readInputData();
                       this.reloadList();
                }
        }
        catch(IOException ex)
        {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    @Override
    public void reloadList() throws IOException {
        load();
    }

    @Override
    public void show() {
         helper.drawUiHeader(this.currentTask.getTaskName()+ " Details");
        try {
            System.out.println("Start Date: " + helper.stringToDateFormat(this.currentTask.getStartDate()));
        } catch (ParseException ex) {
            Logger.getLogger(TaskLogic.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            System.out.println("End Date: " + helper.stringToDateFormat(this.currentTask.getEndDate()));
        } catch (ParseException ex) {
            Logger.getLogger(TaskLogic.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("Status: " + this.currentTask.getStatus());
        // Show Dependencies
        int counter = 1;
        System.out.println("");
        System.out.println("Dependencies: ");
        for(Task task : this.currentTask.getDependencies())
        {
             try {
                 System.out.println(" " + counter + "." + " " + task.getTaskName());
                 System.out.println(" Start Date: " + helper.stringToDateFormat(task.getStartDate()));
                 System.out.println(" End Date: " + helper.stringToDateFormat(task.getEndDate()));
                 System.out.println(" Status: " + task.getStatus());
             } catch (ParseException ex) {
                 Logger.getLogger(TaskLogic.class.getName()).log(Level.SEVERE, null, ex);
             }
          counter += 1;
          System.out.println("");
        }
        System.out.println();
        helper.drawUiFooter();
    }

    @Override
    public void createItem(String name) throws IOException {
        for(Task task : this.currentProjectPlan.getTasks())
        {
            if (task.getTaskName().toLowerCase().equals(name.toLowerCase()))
            {
                this.currentTask.getDependencies().add(task);
                break;
            }
        }
        //Update project plan from list with current project plan
        updateProjectPlanTask();
        dataObjMapper.writeToFile(dataFilePath + "\\" + helper.generateJsonFileName(this.companyScheduler.getCompanyName()), this.companyScheduler);
    }

    @Override
    public void setCurrentItem(int index) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setCurrentItem(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean isExistingItem(String name) {
        boolean result = false;
        for(Task task : this.currentTask.getDependencies())
        {
            if (task.getTaskName().toLowerCase().equals(name.toLowerCase()))
            {
                result = true;
                break;
            }
        }
        return result;
    }

    @Override
    public void removeItem(int index) throws IOException {
         this.currentTask.getDependencies().remove(index);
        //Update project plan from list with current project plan
        updateProjectPlanTask();
        dataObjMapper.writeToFile(dataFilePath + "\\" + helper.generateJsonFileName(this.companyScheduler.getCompanyName()), this.companyScheduler);
    }
    
     private void updateProjectPlanTask()
    {
        //Update task inside the project plan
        for(Task task : this.currentProjectPlan.getTasks())
        {
            if (task.getTaskName().equals(this.currentTask.getTaskName()))
            {
                task = this.currentTask;
                break;
            }
        }
        
        //Update project plan inside the sheduler
        for(ProjectPlan pp : this.companyScheduler.getProjectPlans())
        {
            if (pp.getProjectName().equals(this.currentProjectPlan.getProjectName()))
            {
                pp = this.currentProjectPlan;
                break;
            }
        }
    }
     
    private void updateTaskStatus() throws IOException{
        System.out.println("Please enter the new status (Started|Completed): ");
        switch (helper.readInputData().toLowerCase()){
               case "started":
                   // Add status change rule for Started
                   if (this.currentTask.getStatus().toLowerCase().equals("pending"))
                   {
                       if(isReadyToStart())
                       {
                           this.currentTask.setStatus("Started");
                           updateProjectPlanTask();
                           dataObjMapper.writeToFile(dataFilePath + "\\" + helper.generateJsonFileName(this.companyScheduler.getCompanyName()), this.companyScheduler);
                           load();
                       }
                       else
                       {
                           System.out.println("We cannot set it to 'Started' until all the dependecies are 'Completed'.");
                           helper.readInputData();
                           load();
                       }
                   }
                   else
                   {
                       System.out.println("We cannot set it to 'Started' because it is not in 'Pending' status.");
                       helper.readInputData();
                       load();
                   }
                   break;
               case "completed":
                   // Add status change rule for Completed
                   if (this.currentTask.getStatus().toLowerCase().equals("started"))
                   {
                       this.currentTask.setStatus("Completed");
                       updateProjectPlanTask();
                       dataObjMapper.writeToFile(dataFilePath + "\\" + helper.generateJsonFileName(this.companyScheduler.getCompanyName()), this.companyScheduler);
                       load();
                   }
                   else
                   {
                       System.out.println("We cannot set it to 'Completed' because it is not in 'Started' status.");
                       helper.readInputData();
                       load();
                   }
                   break;
               default:
                   System.out.println("Invalid Input.");
                   helper.readInputData();
                   load();

            }   
    }
    
    private void addTaskDependency() throws IOException{
        System.out.println("Please enter the task name you want to add: ");
        String newDependency = helper.readInputData().toLowerCase();
        //Check if the new task dependency is valid
        if (!newDependency.toLowerCase().equals(this.currentTask.getTaskName().toLowerCase()))
        {
            if (isExistingProjectPlanTask(newDependency) && !isExistingTaskDependency(newDependency))
            {
                createItem(newDependency);
                load();
            }
            else
            {
                System.out.println("Invalid task dependency name.");
                helper.readInputData();
                load();
            }
        }
        else
        {
            System.out.println("You cannot add the same task as dependency.");
            helper.readInputData();
            load();
        }
    
    }
    
    private boolean isReadyToStart(){
        if (this.currentTask.getDependencies().size() > 0)
        {
            boolean isReady = true;
            for (Task dep : this.currentTask.getDependencies())
            {
                if(!dep.getStatus().toLowerCase().equals("completed"))
                {
                    isReady = false;
                    break;
                }
            }
            return isReady;
        }
        else
            return true;
    }
    
    private boolean isExistingTaskDependency(String name){
        boolean result = false;
        
        if (this.currentTask.getDependencies().size() > 0)
        {
            for (Task task : this.currentTask.getDependencies())
            {
                if(task.getTaskName().toLowerCase().equals(name.toLowerCase()))
                {
                    result = true;
                    break;
                }
            }
        }
        
        return result;
    }
    
    private boolean isExistingProjectPlanTask(String name){
        boolean result = false;
        
        for (Task task : this.currentProjectPlan.getTasks())
        {
            if(task.getTaskName().toLowerCase().equals(name.toLowerCase()))
            {
                result = true;
                break;
            }
        }
        return result;
    }
}
